import streamlit as st
import pandas as pd
import joblib
import time

# Cargar el modelo y el scaler
model = joblib.load('random_forest.pkl')
scaler = joblib.load('scaler.pkl')

# Cargar el dataframe para obtener promedios de presión arterial
df = pd.read_csv("cardio_train_normalizado.csv")
df = df.filter(items=["age", "gender", "ap_hi", "ap_lo"])

# Función para obtener presión arterial basada en edad y género
def get_blood_pressure(gender, age):
    df_filtered = df[(df["gender"] == gender)]
    if age < 40:
        df_filtered = df_filtered[df_filtered["age"] < 40]
    elif 40 <= age < 61:
        df_filtered = df_filtered[(df_filtered["age"] >= 40) & (df_filtered["age"] < 61)]
    else:
        df_filtered = df_filtered[df_filtered["age"] >= 61]
    
    mean_ap_hi = round(df_filtered["ap_hi"].mean())
    mean_ap_lo = round(df_filtered["ap_lo"].mean())
    return mean_ap_hi, mean_ap_lo

# Función para reemplazar 'no sé' con los promedios correspondientes
def replace_no_se_with_average(user_data):
    age = user_data['age']
    gender = user_data['gender']

    if user_data['ap_hi'] == 'no sé' or user_data['ap_lo'] == 'no sé':
        mean_ap_hi, mean_ap_lo = get_blood_pressure(gender, age)
        if user_data['ap_hi'] == 'no sé':
            user_data['ap_hi'] = mean_ap_hi
        if user_data['ap_lo'] == 'no sé':
            user_data['ap_lo'] = mean_ap_lo
    
    # Reemplazar otros 'no sé' con valores predeterminados
    for key in user_data:
        if user_data[key] == 'no sé':
            user_data[key] = 0 

    return user_data

# Función para normalizar los datos del usuario
def normalize_user_data(user_data_list):
    user_df = pd.DataFrame([user_data_list], columns=["age", "gender", "height", "weight", "ap_hi", "ap_lo", "cholesterol", "gluc", "smoke", "alco", "active"])
    user_df = pd.DataFrame(scaler.transform(user_df), columns=user_df.columns)
    return user_df.values

# Función para procesar los datos del usuario
def process_user_data(user_data):
    # Reemplazar 'no sé' con valores numéricos adecuados
    user_data = replace_no_se_with_average(user_data)

    # Crear una lista con los datos del usuario
    user_data_list = [
        user_data['age'],
        user_data['gender'],
        user_data['height'],
        user_data['weight'],
        user_data['ap_hi'],
        user_data['ap_lo'],
        user_data['cholesterol'],
        user_data['gluc'],
        user_data['smoke'],
        user_data['alco'],
        user_data['active']
    ]
    
    # Normalizar los datos del usuario
    normalized_data = normalize_user_data(user_data_list)
    
    return normalized_data

# Función para predecir el riesgo
def user_predict(data):
    prediccion = model.predict(data)
    if prediccion[0] == 0:
        return "¡Felicidades, usted No tiene riesgo de un ataque al corazón!"
    else:
        return "¡Tiene riesgo de un ataque cardíaco, visite su médico!"

# Interfaz de usuario con Streamlit
def mostrar_formulario():
    st.title("Formulario de Datos Personales")
    st.write("Por favor, completa los siguientes campos con la información solicitada. Si no sabes la respuesta para algún campo, escribe 'no sé'.")
    with st.form(key='user_form'):
        age = st.number_input("Edad", min_value=1, max_value=120, step=1, value=1)
        gender = st.selectbox("Género", options=[None, 1, 2], format_func=lambda x: "Seleccionar" if x is None else "Hombre" if x == 1 else "Mujer")
        height = st.number_input("Altura (cm)", min_value=0, max_value=250, step=1)
        weight = st.number_input("Peso (kg)", min_value=0, max_value=300, step=1)
        ap_hi = st.text_input("Presión Sistólica", value="no sé")
        ap_lo = st.text_input("Presión Diastólica", value="no sé")
        cholesterol = st.selectbox("Nivel de Colesterol", options=[1, 2, 3], format_func=lambda x: "Normal" if x == 1 else ("Por encima de lo normal" if x == 2 else "Bien por encima de lo normal"), index=0)
        gluc = st.selectbox("Nivel de Glucosa", options=[1, 2, 3], format_func=lambda x: "Normal" if x == 1 else ("Por encima de lo normal" if x == 2 else "Bien por encima de lo normal"), index=0)
        smoke = st.selectbox("¿Fuma?", options=[0, 1], format_func=lambda x: "No" if x == 0 else "Sí", index=0)
        alco = st.selectbox("¿Consume alcohol?", options=[0, 1], format_func=lambda x: "No" if x == 0 else "Sí", index=0)
        active = st.selectbox("¿Realiza ejercicio regularmente?", options=[0, 1], format_func=lambda x: "No" if x == 0 else "Sí", index=0)

        submit_button = st.form_submit_button(label='Enviar Datos')     
        if submit_button:
            st.session_state['user_data'] = {
                'age': age,
                'gender': gender if gender is not None else 'no sé',
                'height': height if height != 0 else 'no sé',
                'weight': weight if weight != 0 else 'no sé',
                'ap_hi': ap_hi,
                'ap_lo': ap_lo,
                'cholesterol': cholesterol,
                'gluc': gluc,
                'smoke': smoke,
                'alco': alco,
                'active': active
            }
            st.success("Datos enviados. Ahora puede proceder a la predicción.")
            time.sleep(3)  
            st.empty()  

def ver_prediccion():
    if 'user_data' in st.session_state and st.session_state['user_data'] is not None:
        st.header("Predicción del Riesgo Cardíaco")
        if st.button('Hacer Predicción'):
            user_data = st.session_state['user_data']
            normalized_data = process_user_data(user_data)
            resultado = user_predict(normalized_data)
            
            st.write("Resultado de la predicción:")
            st.success(resultado)
    else:
        st.warning("Por favor, complete el formulario en la Página 1.")


def main():
    st.sidebar.title("Navegación")
    page = st.sidebar.selectbox("Selecciona una página", ("Formulario", "Predicción"))
    
    if page == "Formulario":
        mostrar_formulario()
    elif page == "Predicción":
        ver_prediccion()

if __name__ == "__main__":
    main()
